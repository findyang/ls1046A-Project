# costmap_prohibition_layer
ROS-Package that implements a costmap layer to add prohibited areas to the costmap-2D by a user configuration.

Build status of the *kinetic-devel* branch:
- Travis (Ubuntu Trusty): [![Build Status](https://travis-ci.org/rst-tu-dortmund/costmap_prohibition_layer.svg?branch=kinetic-devel)](https://travis-ci.org/rst-tu-dortmund/costmap_prohibition_layer)

